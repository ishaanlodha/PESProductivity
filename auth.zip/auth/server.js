const express = require('express');
const bodyParser = require('body-parser');
let jwt = require('jsonwebtoken');
let config = require('./config');
const https = require('https');
const fs = require('fs');
let middleware = require('./middleware');
const csurf = require('csurf');

let app = express();
app.use(bodyParser.urlencoded({
  extended: true
  }));
app.use(bodyParser.json());
const options = {
  key: fs.readFileSync('key.pem'),
  cert: fs.readFileSync('cert.pem')
};

const csrfMiddleware = csurf({
  cookie: true
});

app.get("/", (req, res) => {
	res.send(`<html><head></head><body>
	<form action="/login" method="POST">
      <div>
        <input name="uname" type="text" placeholder = "Username"/>
	<input type="password" name="password" placeholder="Password"/>
      </div>
      <input type="submit" value="Submit" />
      
    </form>
	</body></html>`);
});

app.post("/login", (req, res) => {
console.log("Test");
let username = req.body.username;
    let password = req.body.password;
    // For the given username fetch user from DB
    let mockedUsername = 'admin';
    let mockedPassword = 'password';

    if (username && password) {
      if (username === mockedUsername && password === mockedPassword) {
        let token = jwt.sign({username: username},
          config.secret,
          { expiresIn: '24h' // expires in 24 hours
          }
        );
        // return the JWT token for the future API calls
        id = "Bearer "+token;
        res.cookie("uname",id, { maxAge: 86400, httpOnly: true });
	//res.json({
          //success: true,
         // message: 'Authentication successful!',
        //});
      } else {
        res.send(403).json({
          success: false,
          message: 'Incorrect username or password'
        });
      }}
res.send();    


});

app.get("/test", middleware.checkToken, (req, res) => {
  res.json({
      success: true,
      message: 'Index page'
    });
console.log(req.decoded);
});

https.createServer(options, app).listen(3000, function () {
  console.log('Example app listening on port 3000! Go to https://localhost:3000/')
})

//app.listen(3000, () => console.log(`Server is listening on port: 3000`));

