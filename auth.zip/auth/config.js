module.exports = {
  secret: 'software-engineering-2019-PESUProductivtyApp'
};
